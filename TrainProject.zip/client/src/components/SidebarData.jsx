export const SidebarData = [
    {
        title: 'Home',
        path: '/',
        cName: 'nav-text'
    },
    {
        title: 'About',
        path: '/About',
        cName: 'nav-text'
    },
    {
        title: 'My Bookings',
        path: '/MyBookings',
        cName: 'nav-text'
    },
    {
        title: 'Contact',
        path: '/Contact',
        cName: 'nav-text'
    },
]