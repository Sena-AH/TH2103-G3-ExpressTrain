import '../css/about.css';

function AboutPage() {
    return (
      <div>
        <div className="about-div">
          <div className="grey-rectangle-div"></div>
          <div className="about-font">ABOUT</div>
          <div className="upper-content-font">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec non eros sagittis, auctor neque sit amet, blandit lorem. Etiam molestie.  
          </div>
          <br></br>
          <div className="lower-content-div">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec non eros sagittis, auctor neque sit amet, blandit lorem. Etiam molestie semper mi, ac lacinia justo vulputate quis. Morbi id auctor nibh. Morbi vestibulum bibendum urna id sollicitudin. Suspendisse eu molestie nulla. Maecenas ut convallis ante, eu pretium orci. Cras sed ex massa. Eeey macarena Curabitur odio massa, ultricies at euismod ut, bibendum non tellus.          </div>
          </div>
      </div>
    );
  };

export default AboutPage;