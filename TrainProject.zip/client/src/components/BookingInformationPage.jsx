import BookingForm from './BookingForm';
// import '../css/searchresult.css';


function BookingInformationPage() {

  return (
    <main>
      <h2>Booking Information</h2>

      <BookingForm />

    </main>
  );
};

export default BookingInformationPage;