import React from 'react';

function Footer() {

    return (
      <footer>
        <p>Mail: xxxxx | Address xxxxx | phone: xxxx</p>
        <p>copyright Train app, not for training,</p>
        <p>but for trains 2021 ©</p>
      </footer>
    );
  };

export default Footer;