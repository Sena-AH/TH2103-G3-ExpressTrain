# TH2103-G3
Useful information about the project

## Starta appen
- installera node.js från [nodejs.org](https://nodejs.org/en/download/)  
- starta en New Terminal  
- skriv 'npm install' i terminalen  
- skriv 'npm start' i terminalen  
- högerklicka på client-mappen och välj "Open in Intergrated Terminal"  
- skriv 'npm start' i terminalen

Nu skall sidan starta automatiskt i din webbläsare
