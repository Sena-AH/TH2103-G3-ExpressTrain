
function ContactPage() {
    return (
      <div>
        <p>hello ContactPage</p>
      </div>
    );
  };

export default ContactPage;