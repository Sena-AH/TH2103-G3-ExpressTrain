export const SidebarData = [
    {
        title: 'Home',
        path: '/',
        cName: 'nav-text'
    },
    {
        title: 'About',
        path: '/AboutPage',
        cName: 'nav-text'
    },
    {
        title: 'My Bookings',
        path: '/MyBookingsPage',
        cName: 'nav-text'
    },
    {
        title: 'Contact',
        path: '/ContactPage',
        cName: 'nav-text'
    },
]