function SeatsPage() {
    return(
        <div class="WholePage">
            <h1 class="Title">Seats</h1>

            <div class="TrainCarts">
                
            </div>

            <div class="TotalPrice">
                <p class="TotalPriceText">TOTAL PRICE: XXX KR</p>
                <button class="TotalPriceContinueButton" onclick="">Continue</button>

            </div>
        </div>
    );
};

export default SeatsPage;